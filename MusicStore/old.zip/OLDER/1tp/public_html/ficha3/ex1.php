<!--exercicio 1-->

<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
		<title>Ex1: Hello World</title>
	</head>
	<body>
		<?php
			echo "<p>Hello World</p>";
		?>
	</body>
</html>