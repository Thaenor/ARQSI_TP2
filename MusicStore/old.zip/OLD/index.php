<?php

include 'core/init.php';
include 'includes/overall/Header.php' ?>

<h1>Home</h1>
<p>Just a template</p>

<?php include 'includes/overall/Footer.php' ?>
