<footer>
  &copy; MusicStore 2014. All rights reserved.
</footer>
