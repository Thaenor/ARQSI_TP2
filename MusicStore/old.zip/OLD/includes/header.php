<header>
  <h1 class="logo">Music Store</h1>
<?php include 'includes/menu.php' ?>
  <div class="clear"></div>
</header>
