<div class="widget">
  <h2>Log in/Register</h2>
  <div class="inner">
    <form action="loginController.php" method="post">
      <ul id="login">
        <li>
          Username: <br/>
          <input type="text" name="username">
        </li>
        <li>
          Password: <br/>
          <input type="password" name="password">
        </li>
        <li>
          <input type="submit" value="log in">
        </li>
        <li>
          <a href="register.php">Register</a>
        </li>
      </ul>
    </form>
  </div>
</div>
